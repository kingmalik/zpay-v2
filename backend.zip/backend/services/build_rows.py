from __future__ import annotations
import pandas as pd
from backend.utils.pandas_tools import money_to_float, get_col_ci, parse_date_utc

DETAILS_TO_ROWS_COLS = {
    # output       # input column (Details)
    "external_id": "Key",
    "ride_start_ts": "Date",
    "base_fare": "Gross",
    "distance_miles": "Miles",
    "net_pay": "Net Pay",
    "code": "Code",
    "person": "Person",
    "name": "Name",
}

def details_to_rows(details_df: pd.DataFrame) -> pd.DataFrame:
    """Transform the Details DF into the normalized 'rows' DF (no tips/adj)."""
    rows = pd.DataFrame({
        "external_id": get_col_ci(details_df, DETAILS_TO_ROWS_COLS["external_id"], default="", dtype=str),
        "ride_start_ts": parse_date_utc(get_col_ci(details_df, DETAILS_TO_ROWS_COLS["ride_start_ts"], default="", dtype=str)),
        "base_fare": money_to_float(get_col_ci(details_df, DETAILS_TO_ROWS_COLS["base_fare"], default="", dtype=str)).fillna(0),
        "distance_miles": pd.to_numeric(get_col_ci(details_df, DETAILS_TO_ROWS_COLS["distance_miles"], default="", dtype=str), errors="coerce"),
        "net_pay": money_to_float(get_col_ci(details_df, DETAILS_TO_ROWS_COLS["net_pay"], default="", dtype=str)).fillna(0),
        "code": get_col_ci(details_df, DETAILS_TO_ROWS_COLS["code"], default="", dtype=str),
        "person": get_col_ci(details_df, DETAILS_TO_ROWS_COLS["person"], default="", dtype=str),
        "name": get_col_ci(details_df, DETAILS_TO_ROWS_COLS["name"], default="", dtype=str),
    })

    # keep only rows with a key and valid date
    rows = rows[rows["external_id"].astype(str).str.len() > 0]
    rows = rows[rows["ride_start_ts"].notna()].reset_index(drop=True)
    return rows
