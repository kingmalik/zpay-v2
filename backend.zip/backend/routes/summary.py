from __future__ import annotations
import pandas as pd
from fastapi import APIRouter
from fastapi.responses import HTMLResponse, FileResponse, JSONResponse
from sqlalchemy import select

from backend.db import SessionLocal
from backend.models import Person, Ride
from backend.config import DATA_OUT
from backend.utils.orm_introspect import person_pk_attr, ride_fk_to_person_attr, person_name_fields

router = APIRouter()

@router.get("/summary", response_class=HTMLResponse)
def summary():
    with SessionLocal() as db:
        people = db.execute(select(Person)).scalars().all()
        rides = db.execute(select(Ride)).scalars().all()

    pk_name = person_pk_attr(Person)
    fk_name = ride_fk_to_person_attr(Person, Ride) or "person_id"
    code_field, name_field = person_name_fields(Person)

    recs = []
    pmap = {getattr(p, pk_name): p for p in people}
    for r in rides:
        pid = getattr(r, fk_name, None)
        if pid is None or pid not in pmap:
            continue
        p = pmap[pid]
        code_val = getattr(p, code_field) if code_field else None
        name_val = getattr(p, name_field) if name_field else None
        recs.append({
            "code": code_val or "",
            "person": name_val or "",
            "external_id": getattr(r, "external_id", None),
            "miles": getattr(r, "distance_miles", None),
            "gross": getattr(r, "base_fare", None),
            "net": getattr(r, "net_pay", None),
            "ts": getattr(r, "ride_start_ts", None),
        })

    rows = []
    if recs:
        df = pd.DataFrame(recs)
        agg = (df.groupby(["code", "person"], dropna=False, as_index=False)
                 .agg(rides=("external_id", "nunique"),
                      miles_total=("miles", "sum"),
                      gross_total=("gross", "sum"),
                      net_total=("net", "sum"),
                      first_ride=("ts", "min"),
                      last_ride=("ts", "max")))
        rows = agg.to_records(index=False)

        # write CSV for download
        try:
            (DATA_OUT / "people_summary.csv").parent.mkdir(parents=True, exist_ok=True)
            agg.to_csv(DATA_OUT / "people_summary.csv", index=False)
        except Exception:
            pass

    def fmt(x):
        return "" if pd.isna(x) else x

    html = [
        "<!doctype html><html><body style='font-family: system-ui, sans-serif; padding:24px'>",
        "<h1>Per-Person Summary (Details only)</h1>",
        f"<p>Download CSV: <a href='/download/people_summary.csv'>people_summary.csv</a></p>",
        "<table border='1' cellspacing='0' cellpadding='6'>",
        "<tr><th>Code</th><th>Person</th><th>Rides</th><th>Miles</th><th>Gross</th><th>Net</th><th>First</th><th>Last</th></tr>",
        *[
            "<tr>"
            f"<td>{fmt(code)}</td>"
            f"<td>{fmt(person)}</td>"
            f"<td>{fmt(rides)}</td>"
            f"<td>{fmt(miles_total)}</td>"
            f"<td>{fmt(gross_total)}</td>"
            f"<td>{fmt(net_total)}</td>"
            f"<td>{fmt(first_ride)}</td>"
            f"<td>{fmt(last_ride)}</td>"
            "</tr>"
            for (code, person, rides, miles_total, gross_total, net_total, first_ride, last_ride) in rows
        ],
        "</table>",
        "<p><a href='/'>Home</a> · <a href='/people'>People</a> · <a href='/rides'>Rides</a></p>",
        "</body></html>",
    ]
    return HTMLResponse("\n".join(html))

@router.get("/download/people_summary.csv")
def dl_people_summary():
    p = DATA_OUT / "people_summary.csv"
    return FileResponse(p, filename=p.name, media_type="text/csv") if p.exists() else JSONResponse({"error": "not found"}, status_code=404)

@router.get("/download/details.csv")
def dl_details():
    p = DATA_OUT / "details.csv"
    return FileResponse(p, filename=p.name, media_type="text/csv") if p.exists() else JSONResponse({"error": "not found"}, status_code=404)

@router.get("/download/rows.csv")
def dl_rows():
    p = DATA_OUT / "rows.csv"
    return FileResponse(p, filename=p.name, media_type="text/csv") if p.exists() else JSONResponse({"error": "not found"}, status_code=404)
