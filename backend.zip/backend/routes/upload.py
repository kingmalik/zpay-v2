from __future__ import annotations

import os
import logging
from typing import Dict

import pandas as pd
from fastapi import APIRouter, File, UploadFile, HTTPException
from fastapi.responses import HTMLResponse

from backend.db import SessionLocal
from backend.models import Person, Ride
from backend.config import DATA_OUT
from backend.services.storage import save_upload
from backend.services.parse_details import parse_details
from backend.services.build_rows import details_to_rows
from backend.services.db_people import (
    get_or_create_person,
    build_existing_people_map,
)
from backend.services.db_rides import insert_ride_from_row
from backend.utils.pandas_tools import get_col_ci, parse_date_utc, money_to_float

router = APIRouter()

# -------------------- logging --------------------
logger = logging.getLogger("zpay.upload")
if not logger.handlers:
    level = os.getenv("ZPAY_LOG_LEVEL", "INFO").upper()
    logger.setLevel(getattr(logging, level, logging.INFO))
    handler = logging.StreamHandler()
    handler.setFormatter(logging.Formatter("%(asctime)s [%(levelname)s] %(name)s: %(message)s"))
    logger.addHandler(handler)

PREVIEW_ROWS = int(os.getenv("ZPAY_LOG_PREVIEW_ROWS", "5"))


def _preview_df(df: pd.DataFrame, label: str):
    """Log a compact, readable preview of a dataframe."""
    try:
        if df is None:
            logger.info("%s: <None>", label)
            return
        logger.info("%s: shape=%s, columns=%s", label, df.shape, list(df.columns))
        if not df.empty:
            prev = df.copy()
            # make datetimes readable in logs
            for c in prev.columns:
                if any(k in c.lower() for k in ("date", "time", "ts")):
                    try:
                        prev[c] = pd.to_datetime(prev[c], errors="ignore")
                    except Exception:
                        pass
                prev[c] = prev[c].astype(str)
            logger.info("%s (head): %s", label, prev.head(PREVIEW_ROWS).to_dict(orient="records"))
    except Exception as e:
        logger.warning("preview_df(%s) failed: %s", label, e)


@router.post("/upload", response_class=HTMLResponse)
def upload(file: UploadFile = File(...)):
    """
    Process a payroll PDF using **Details only**:

      1) Save upload (fallback to /tmp if /data is read-only)
      2) Parse Details -> DataFrame
      3) PRE-CREATE People from distinct (Code|Person) pairs (even if rides fail)
      4) Normalize Details -> rows (Key/Date/Miles/Gross/Net)
      5) Insert rides and link to people
      6) Write inspection CSVs

    Extensive logging is emitted so you can see where things go wrong.
    """
    logger.info("=== /upload start ===")
    logger.info("Incoming file: name=%s, type=%s", file.filename, getattr(file, "content_type", "?"))

    # 1) Save upload
    try:
        dest_path = save_upload(file)
        logger.info("Saved upload to: %s", dest_path)
    except Exception as e:
        logger.exception("Failed to save upload")
        raise HTTPException(status_code=500, detail=f"Failed to save upload: {e}")

    # 2) Parse Details only
    try:
        details_df = parse_details(str(dest_path))
        logger.info("Parsed Details: rows=%d", 0 if details_df is None else len(details_df))
        _preview_df(details_df, "Details DF")
    except Exception as e:
        logger.exception("Failed to parse details")
        raise HTTPException(status_code=500, detail=f"Failed to parse details: {e}")

    # Diagnostics to understand why normalization may drop rows
    try:
        if details_df is not None and not details_df.empty:
            key_s = get_col_ci(details_df, "Key", default="", dtype=str)
            date_s = parse_date_utc(get_col_ci(details_df, "Date", default="", dtype=str))
            gross_s = money_to_float(get_col_ci(details_df, "Gross", default="", dtype=str))
            net_s = money_to_float(get_col_ci(details_df, "Net Pay", default="", dtype=str))

            missing_key = int((key_s.astype(str).str.len() == 0).sum())
            missing_date = int(date_s.isna().sum())
            missing_gross = int(gross_s.isna().sum())
            missing_net = int(net_s.isna().sum())
            logger.info(
                "Details diagnostics: total=%d, missing Key=%d, missing Date(parse)=%d, "
                "missing Gross=%d, missing Net Pay=%d",
                len(details_df), missing_key, missing_date, missing_gross, missing_net
            )
            logger.info(
                "Distinct Person=%d, Code=%d",
                details_df.get("Person", pd.Series([], dtype=str)).nunique(dropna=True),
                details_df.get("Code", pd.Series([], dtype=str)).nunique(dropna=True),
            )
    except Exception as e:
        logger.warning("Details diagnostics failed: %s", e)

    # 3) PRE-CREATE PEOPLE from (Code|Person) pairs (so /people is useful even if rides=0)
    pre_created = 0
    try:
        if details_df is not None and not details_df.empty:
            raw_code = get_col_ci(details_df, "Code", default="", dtype=str)
            # Code often looks like "141097 9/2/2025 - 9/5/2025"; keep the leading token as actual code
            codes = raw_code.str.extract(r"^\s*([0-9A-Za-z\-_]+)")[0].fillna("")
            persons = get_col_ci(details_df, "Person", default="", dtype=str).fillna("")

            pre_df = (
                pd.DataFrame({"code": codes, "person": persons})
                .assign(key=lambda d: (d["code"].fillna("") + "|" + d["person"].fillna("")).str.strip())
                .query("key != '|'")
                .drop_duplicates("key")
            )

            with SessionLocal() as db:
                people_cache = build_existing_people_map(db, Person)
                before = len(people_cache)
                for _, row in pre_df.iterrows():
                    _ = get_or_create_person(
                        db, Person,
                        row["code"], row["person"],
                        existing_by_key=people_cache,
                    )
                db.commit()
                pre_created = len(people_cache) - before

            logger.info("Pre-created people from Details (unique code|person pairs): %d", pre_created)
        else:
            logger.info("Pre-create people skipped: empty Details")
    except Exception as e:
        logger.warning("Pre-create people failed: %s", e)

    # 4) Normalize Details -> rows
    rows = details_to_rows(details_df)
    logger.info("Normalized rows: %d", len(rows))
    _prev = rows.copy()
    if "ride_start_ts" in _prev.columns:
        _prev["ride_start_ts"] = _prev["ride_start_ts"].astype(str)
    _preview_df(_prev, "Rows DF")

    # 5) Insert rides & link to people
    created_rides = 0
    created_people_during_rides = 0
    with SessionLocal() as db:
        people_cache: Dict[str, object] = build_existing_people_map(db, Person)
        logger.info("People cache (before rides): %d", len(people_cache))

        for i, rec in enumerate(rows.to_dict(orient="records")):
            try:
                before = len(people_cache)
                person = get_or_create_person(
                    db,
                    Person,
                    rec.get("code", ""),
                    rec.get("person", ""),
                    existing_by_key=people_cache,
                )
                if len(people_cache) > before:
                    created_people_during_rides += 1

                insert_ride_from_row(db, Ride, person, rec)
                created_rides += 1

                if i < PREVIEW_ROWS:
                    logger.info(
                        "Inserted ride %d/%d: key=%s person(code=%s,name=%s) date=%s gross=%s miles=%s net=%s",
                        i + 1, len(rows),
                        rec.get("external_id"),
                        (rec.get("code") or ""),
                        (rec.get("person") or ""),
                        rec.get("ride_start_ts"),
                        rec.get("base_fare"),
                        rec.get("distance_miles"),
                        rec.get("net_pay"),
                    )
            except Exception:
                logger.exception(
                    "Failed to insert row %d: key=%s person(code=%s,name=%s)",
                    i + 1, rec.get("external_id"), rec.get("code"), rec.get("person"),
                )

        db.commit()
        logger.info(
            "DB commit complete. pre_created_people=%d, new_people_during_rides=%d, new_rides=%d",
            pre_created, created_people_during_rides, created_rides
        )

    # 6) Write inspection CSVs
    try:
        DATA_OUT.mkdir(parents=True, exist_ok=True)
        details_csv = DATA_OUT / "details.csv"
        rows_csv = DATA_OUT / "rows.csv"
        details_df.to_csv(details_csv, index=False)
        rows.to_csv(rows_csv, index=False)
        logger.info("Wrote CSVs: %s , %s", details_csv, rows_csv)

        if not rows.empty:
            people_agg = (
                rows.groupby(["code", "person"], dropna=False, as_index=False)
                .agg(
                    rides=("external_id", "nunique"),
                    miles_total=("distance_miles", "sum"),
                    gross_total=("base_fare", "sum"),
                    net_total=("net_pay", "sum"),
                    first_ride=("ride_start_ts", "min"),
                    last_ride=("ride_start_ts", "max"),
                )
            )
            people_summary_csv = DATA_OUT / "people_summary.csv"
            people_agg.to_csv(people_summary_csv, index=False)
            logger.info("Wrote summary CSV: %s", people_summary_csv)
            _preview_df(people_agg, "People Summary (from rows)")
    except Exception as e:
        logger.warning("Writing CSVs failed: %s", e)

    logger.info(
        "=== /upload done: pre_created_people=%d, created_people_during_rides=%d, created_rides=%d ===",
        pre_created, created_people_during_rides, created_rides
    )

    return HTMLResponse(
        f"<h2>Processed {created_rides} rides from Details.</h2>"
        f"<p>Saved upload: <code>{dest_path}</code></p>"
        f"<p>Raw Details → <code>{DATA_OUT / 'details.csv'}</code> | "
        f"Rows → <code>{DATA_OUT / 'rows.csv'}</code> | "
        f"People Summary → <code>{DATA_OUT / 'people_summary.csv'}</code></p>"
        f'<p><a href="/">Home</a> · <a href="/people">People</a> · '
        f'<a href="/rides">Rides</a> · <a href="/summary">Summary</a></p>'
    )
