from __future__ import annotations

from fastapi import FastAPI
from fastapi.responses import HTMLResponse, JSONResponse

# shows the resolved data directory on the homepage
from backend.config import DATA_DIR

# mount the modular routers
from backend.routes.upload import router as upload_router
from backend.routes.people import router as people_router
from backend.routes.rides import router as rides_router
from backend.routes.summary import router as summary_router


app = FastAPI(title="Z-Pay (Details Only • Modular)")

HOME_HTML = f"""
<!doctype html><html><body style="font-family: system-ui, sans-serif; padding: 24px">
  <h1>Z-Pay • Details-only Upload</h1>
  <p>Data dir: <code>{DATA_DIR}</code></p>

  <form action="/upload" method="post" enctype="multipart/form-data" style="margin:16px 0">
    <input type="file" name="file" accept="application/pdf" required />
    <button type="submit">Upload</button>
  </form>

  <p>
    <a href="/people">People</a> ·
    <a href="/rides">Rides</a> ·
    <a href="/summary">Summary</a>
  </p>
</body></html>
"""

@app.get("/", response_class=HTMLResponse)
def home():
    return HOME_HTML

@app.get("/healthz")
def healthz():
    return JSONResponse({"ok": True, "data_dir": str(DATA_DIR)})

# Routers (Details-only flow; no Summary parsing, no tips/adjustments, no Person.external)
app.include_router(upload_router)
app.include_router(people_router)
app.include_router(rides_router)
app.include_router(summary_router)
